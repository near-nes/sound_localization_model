function [metric, doa_corr] = mclachlan2024_metrics(doa,varargin)
%MCLACHLAN2021_METRICS - extract localization metrics
%   Usage: metric = mclachlan2021_metrics(doa) 
%
%   Input parameters:
%     doa               : Struct returned from the mclachlan2021 model with
%                         estimated and real directions of arrival
%
%   Output parameters:
%     metric            : metrics for evaluation of localisation
%                         performance
%
%   mclachlan2021_metrics(...) returns psychoacoustic performance 
%   parameters for experimental response patterns. 
%   doa is a struct where actual and estimated directions of arrival must
%   be provided.
%
%   The metrics struct contains the following fields:
%   
%     .reversal_fb      Percentage of front-back reversals, omitting
%                       small errors occurring within 10 degrees of the
%                       plane dividing the hemifields
%
%     .reversal_ud      Percentage of up-down reversals, omitting
%                       small errors occurring within 10 degrees of the
%                       plane dividing the hemifields
%
%     .rmsL             Lateral root mean squared error
%
%     .rmsP             Polar root mean squared error, omitting reversals
%                       and restricted to directions within 35 degrees of
%                       the vertical midline
%
%   
%   See also: demo_mclachlan2021 mclachlan2021
%
%   References:
%     D. Schonstein, L. Ferre, and B. F. G. Katz. Comparison of headphones
%     and equalization for virtual auditory source localization. Proc.
%     Euronoise, 2008.
%     
%     J. Reijniers, D. Vanderleist, C. Jin, C. S., and H. Peremans. An
%     ideal-observer model of human sound localization. Biological
%     Cybernetics, 108:169--181, 2014.
%     
%
%   Url: http://amtoolbox.org/amt-1.5.0/doc/modelstages/mclachlan2024_metrics.php


%   #StatusDoc: Perfect
%   #StatusCode: Perfect
%   #Verification: Unknown
%   #Requirements: M-Signal M-Image
%   #Author: Michael Sattler
%   #Author: Roberto Barumerli
%   #Author: Glen McLachlan (2021)

% This file is licensed unter the GNU General Public License (GPL) either 
% version 3 of the license, or any later version as published by the Free Software 
% Foundation. Details of the GPLv3 can be found in the AMT directory "licences" and 
% at <https://www.gnu.org/licenses/gpl-3.0.html>. 
% You can redistribute this file and/or modify it under the terms of the GPLv3. 
% This file is distributed without any warranty; without even the implied warranty 
% of merchantability or fitness for a particular purpose. 

% real doa, in spherical and lat-pol coordinates
sph_real = SOFAconvertCoordinates(doa.real, 'cartesian', 'spherical');
[lat_real,pol_real]=sph2horpolar(sph_real(:,1),sph_real(:,2));
num_dirs = size(doa.real,1);
doa.est = squeeze(doa.est);

if size(doa.est, 3) ~= 1 % remove third dimension relative to repetition of experiments
    num_exp = size(doa.est, 2);
    doa_est = [];

    for i = 1:size(doa.est, 1)
        est = squeeze(doa.est(i,:,:));
        doa_est = [doa_est; est];
    end
else
    if(size(doa.est, 1) == num_dirs)
        num_exp = 1;
    else
        num_exp = size(doa.est, 1);
    end
    doa_est = doa.est;
end

% mean estimated doa over all experiments, in spherical and lat-pol coordinates
sph_est = SOFAconvertCoordinates(doa_est, 'cartesian', 'spherical');
[lat_est,pol_est] = sph2horpolar(sph_est(:,1),sph_est(:,2));

% matrix of all doas
m = zeros(size(sph_real, 1)*num_exp, 14);
m(:, 1:2) = repelem(sph_real(:, [1 2]), num_exp, 1);     % spherical real
m(:, 3:4) = sph_est(:, [1 2]);                          % spherical estimate
m(:, 5:6) = repelem([lat_real,pol_real], num_exp, 1);    % lat-pol real
m(:, 7:8) = [lat_est,pol_est];                          % lat-pol estimate
m(:, 9:11) = repelem(doa.real(:,1:3),num_exp, 1);        % cartesian real
m(:, 12:14) = doa_est(:,1:3);                           % cartesian estimate

% ensure real values, as sph2horpolar can return complex numbers 
% due to numerical approximations
m = real(m);

%% metrics

% percentage of front-back confusions according to Carlile et al. (1999)
idx_fb = find(sign(m(:,9))~=sign(m(:,12)) & abs(m(:,9))>0.01);
idx_nofb = setxor(1:size(m,1),idx_fb);
log_fb = (sign(m(:,9))~=sign(m(:,12)) & abs(m(:,9))>0.01);

idx_ud = find(sign(m(:,11))~=sign(m(:,14)) & abs(m(:,11))>0.01);
idx_noud = setxor(1:size(m,1),idx_ud);

%idx_c = unique([idx_fb;idx_ud]);

doa_corr.est=doa.est(idx_nofb,:); doa_corr.real=doa.real(idx_nofb,:); %remove fbc

[uniq,~,ic1] = unique(doa.real,'rows');
bias_perdir=zeros(size(uniq,1),3);
for i=idx_nofb' % compute bias vectors per direction
    bias_perdir(ic1(i),:)=bias_perdir(ic1(i),:)+doa.est(i,:);
end
metric.bias_perdir=bias_perdir./sqrt(sum(bias_perdir.^2,2));
bias_pol=SOFAconvertCoordinates(metric.bias_perdir,'cartesian','spherical');
bias_pol=bias_pol/180*pi;

metric.bias_norm=sqrt(sum(metric.bias_perdir.^2,2));

fbc_perdir=zeros(length(uniq),1);
for i=idx_fb' % compute percentage of fb confusions per direction
    fbc_perdir(ic1(i))=fbc_perdir(ic1(i))+log_fb(i);
end
metric.fbc_perdir=fbc_perdir/(length(log_fb)/length(fbc_perdir))*100;
metric.fbc_mean=mean(fbc_perdir);
% absolute lateral error
metric.laterr=abs(mynpi2pi(m(:,7)-m(:,5)));
metric.polerr=abs(mynpi2pi(m(:,8)-m(:,6)));
metric.elerr=abs(mynpi2pi(m(:,4)-m(:,2)));
metric.azerr=abs(mynpi2pi(m(:,3)-m(:,1)));

for j=1:length(uniq) % per true source direction
didx= find(ismember(doa_corr.real,uniq(j,:),'rows'));
n = length(didx);
d=doa_corr.est;

% compute Kent parameters
T = [	sum(d(didx,1) .* d(didx,1)), sum(d(didx,1) .* d(didx,2)), sum(d(didx,1) .* d(didx,3)) ; 
	sum(d(didx,1) .* d(didx,2)), sum(d(didx,2) .* d(didx,2)), sum(d(didx,2) .* d(didx,3)) ;
	sum(d(didx,1) .* d(didx,3)), sum(d(didx,2) .* d(didx,3)), sum(d(didx,3) .* d(didx,3)) ];
S = T / n;
H = [	cos(bias_pol(j,1))*sin(bias_pol(j,2)) sin(bias_pol(j,1))*sin(bias_pol(j,2)) -cos(bias_pol(j,2));
	-sin(bias_pol(j,1))		cos(bias_pol(j,1))	0;
	cos(bias_pol(j,1))*cos(bias_pol(j,2)) sin(bias_pol(j,1))*cos(bias_pol(j,2)) sin(bias_pol(j,2))]';
B = H' * S * H;
psi = 0.5 * atan2(2 * B(1,2), (B(1,1) - B(2,2)));
K = [cos(psi) -sin(psi) 0; sin(psi) cos(psi) 0; 0 0 1];
G = H * K;

% rd is a rotated version of responses which should be centered about hp coord (0,90)
rd = (G^(-1) * d(didx,:)')';

% calculate mean and std dev
uv = mean(rd);
sigv = std(rd);

% now figure out ellipse size for std deviation
ellz = sigv(1:2) / 1;
if (ellz(1) < ellz(2))
	fprintf('maj=%g < min=%g', ellz(1), ellz(2));
	error('should not happen');
end

% compute the points of the ellipse and rotate into original coordinates
PP=40;
for i=1:PP-1
   psi=i/PP*2*pi;
   x = ellz(1) * sin(psi);
   y = ellz(2) * cos(psi);
   z = abs(sqrt(1 - x*x - y*y));
   xyz = (G * [x;y;z])';	% convert to orig coords
   ell(j,i,:) = xyz;
end
ell(j,PP,:)=ell(j,1,:); % copy first to last to complete circle
end

metric.kentdist=ell;





% idx = find(abs(m(:,5))<=35); % ignore 10 degrees around interaural axis
% idx_fbm = intersect(idx,idx_fb);
% idx_udm = intersect(idx,idx_ud); 

% metric.mean_fbc = size(idx_fbm,1)*100/size(m,1); %percent fb reversals
% metric.mean_udc = size(idx_udm,1)*100/size(m,1); %percent ud reversals

% polar RMS excluding quadrant errors and 10 degrees around interaural axis
% m_rmsP = m;
% m_rmsP([idx_fb; idx_ud],:) = [];
% idx = abs(m_rmsP(:,5))<=35; % ignore 10 degrees around interaural axis
% m_rmsP = m_rmsP(idx,:);
% 
% metric.rmsP=sqrt(sum((mynpi2pi(m_rmsP(:,8)-m_rmsP(:,6))).^2)/size(m_rmsP,1));

    % plottable data, omitting dirs near midline
    pol_err = abs(mynpi2pi(m(:,8)-m(:,6))); % plottable polar error
    lat_err = abs(mynpi2pi(m(:,7)-m(:,5))); % plottable lateral error
    p_err = sum(reshape(pol_err,num_dirs,num_exp),2)/num_exp;
    l_err = sum(reshape(lat_err,num_dirs,num_exp),2)/num_exp;

    if isempty(varargin)
        error = 'none';
    else
        error = varargin{1};
    end
end

function out_deg=mynpi2pi(ang_deg)
ang=ang_deg/180*pi;
out_rad=sign(ang).*((abs(ang)/pi)-2*ceil(((abs(ang)/pi)-1)/2))*pi;
out_deg=out_rad*180/pi;
end

