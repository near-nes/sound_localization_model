from scipy import signal
from scipy import linalg, special, fft as sp_fft
