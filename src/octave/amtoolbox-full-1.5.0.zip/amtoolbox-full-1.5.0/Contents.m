% AMT - Online documentation
%
%
%  General
%  -------
%
%  This is the most complete, and up-to-date description of the AMT. This documentation is directly included in the M-files and it is auto-generated for this website. Because of the automatic generation, the appearance on the website may suffer some details. Note that the current status of the models can be found in the section `Models <https://test.amtoolbox.org/models.php at this website.
%
%
%  New to the AMT? 
%  ---------------
%
%  Download the AMT full package <https://test.amtoolbox.org/download.php, which provides all third-party toolboxes, start the AMT with AMT_START and compile the binaries with amt_mex. To stop the session, use amt_stop` which removes the added paths and resets the configuration. 
%
%  Note that the installation can be also done by calling amt_start('install'), which downloads the third-party toolboxes (if missing) and triggers compilation of the binaries. 
%
%
%  Important files in the AMT base path:
%  -------------------------------------
%
%    AMT_START            - Start the AMT and load the third-party toolboxes available on the system.
%
%    CHANGES              - Release history through out the AMT versions 
%
%
%
%  Requirements to run the AMT 1.x
%  -------------------------------
%
%  Matlab 2018b (or more recent) or Octave 8.2 (or more recent). Further, the large time-frequency analysis toolbox (*LTFAT*) is essential. It will be downloaded and installed by amt_start on the fly if not available on the system. Note that because of a bug in Octave 8.2.0 (or older) on Windows, Octave needs to be installed in a directory path without blanks. 
%
%  The model-specific requirements are as follows:
%
%  1) Many models require compiled binaries. We provide pre-compiled binaries within the AMT full package, however, compilation on your system may still be required. To this end, the AMT needs to access the GNU Compiler Collection (GCC). The availability can be checked by executing system('gcc --version'); in Matlab or Octave. To compile the AMT binaries, execute amt_mex. 
%
%  2) The models VERHULST2012, VERHULST2015, and VERHULST2018 require Python (version >= 2.6) with the packages numpy and scipy. On Linux, install the packages in the shell: sudo apt-get install python-scipy python-numpy. On Windows, install Python <https://www.python.org/ and add python.exe to the Windows search path. Then install the packages by executing python -m pip install numpy scipy in the Windows Command Window. In Matlab/Octave check the Python version with system('python -V')`.
%
%  3) System-dependent toolboxes may be required for some models. On Matlab, mostly the Signal Processing and the Statistics Toolbox may be required. On Octave, the signal, statistics, netcdf, and optim packages may be required. Type amt_info('model'); with model being the model name to display the model-specific requirements (see AMT_INFO for more details). 
%
%  4) Third-party toolboxes may be required, depending on the model. The AMT assumes that the user provides the paths to the toolboxes via the Matlab/Octave search paths. All third-party toolboxes are provided in the AMT full package <https://test.amtoolbox.org/download.php. In addition to that, amt_start('install'); downloads and installs all third-party toolboxes to the AMT's directory thirdparty`. 
%
% 
%  License:
%  --------
%
%  The AMT is a MULTIPLE-licenses software: Most of the files are 
%  licensed under the GPL version 3.0, but some files are licensed differently.
%  Each file contains a separate license boilerplate showing the actual license.
%  For models being NOT under GPL3, the boilerplate is displayed on their first run. 
%  If no license message is displayed, the model is licensed under the GPL3. 
%  The information about the license of a model can be shown by amt_info. 
%
%   Url: http://amtoolbox.org/amt-1.5.0/doc/Contents.php


%   #Author: Peter L. Soendergaard (2013) 
%   #Author: Piotr Majdak (2013-)

% This file is licensed unter the GNU General Public License (GPL) either 
% version 3 of the license, or any later version as published by the Free Software 
% Foundation. Details of the GPLv3 can be found in the AMT directory "licences" and 
% at <https://www.gnu.org/licenses/gpl-3.0.html>. 
% You can redistribute this file and/or modify it under the terms of the GPLv3. 
% This file is distributed without any warranty; without even the implied warranty 
% of merchantability or fitness for a particular purpose. 


